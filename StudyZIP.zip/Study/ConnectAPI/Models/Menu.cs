﻿namespace ConnectAPI.Models
{
    public class Menu
    {
        public int Codigo { get; set; }
        public string Nome { get; set; }
        public string Descricao { get; set; }
        public string DataCriacao { get; set; }
    }
}
